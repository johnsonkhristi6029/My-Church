//
//  ViewController.swift
//  my chruch
//
//  Created by Johnson Khristion 11/11/17.
//  Copyright © 2017 Johnson Khristi. All rights reserved.
//

import UIKit
import MapKit
class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource, UIPickerViewDelegate, UIPickerViewDataSource {
    
    @IBOutlet weak var pickeroutlet: UIPickerView!
    @IBOutlet weak var pickerview: UIView!
    let annotation = MKPointAnnotation()
    var maindata:NSArray = NSArray()
    var selectedindex:Int = -1
    @IBOutlet weak var lblselected: UILabel!
    @IBOutlet weak var tableviewoutlet: UITableView!
    @IBOutlet weak var mapV: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        maindata = NSArray.init(objects: ["church_img":"img1.jpg","church_name":"GCC","church_pastor":"xyz","church_area":"Brampton","lattitude":"43.659039","longitude":"-79.742725"],["church_img":"img2.jpg","church_name":"Knox United","church_pastor":"john","church_area":"North York","lattitude":"43.786258","longitude":"-79.278444"],["church_img":"img3.jpg","church_name":"Malvern prebiestrian","church_pastor":"Ravi","church_area":"Scarborough","lattitude":"43.807135","longitude":"-79.218480"],["church_img":"img4.jpg","church_name":"St. Petrick  Church","church_pastor":"Petrick","church_area":"Missisaga","lattitude":"43.608004","longitude":"-79.601083"])
        mapV.mapType = MKMapType.standard
        mapV.addAnnotation(annotation)
        setlocation(location: CLLocationCoordinate2D(latitude: 45.1510532655634,longitude:-79.398193359375))
        pickeroutlet.reloadAllComponents()
        tableviewoutlet.reloadData()
        // Do any additional setup after loading the view, typically from a nib.
    }
    func setlocation(location:CLLocationCoordinate2D) {
        let span = MKCoordinateSpanMake(0.05, 0.05)
        let region = MKCoordinateRegion(center: location, span: span)
        mapV.setRegion(region, animated: true)
        
        // 4)
        annotation.coordinate = location
  
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if selectedindex != -1 {
            return 1
        }
        else
        {
            return 0
        }
    }
    
    // create a cell for each table view row
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        // create a new cell if needed or reuse an old one
        let cell:UITableViewCell = tableView.dequeueReusableCell(withIdentifier: "reuse", for: indexPath )
        
        let img1:UIImageView = cell.viewWithTag(1) as! UIImageView
        let l1:UILabel = cell.viewWithTag(2) as! UILabel
        let l2:UILabel = cell.viewWithTag(3) as! UILabel

        if selectedindex != -1 {
            img1.image = UIImage.init(named: (maindata.object(at: selectedindex) as! NSDictionary).value(forKey: "church_img") as! String)
            l1.text =  (maindata.object(at: selectedindex) as! NSDictionary).value(forKey: "church_pastor") as? String
            l2.text =  (maindata.object(at: selectedindex) as! NSDictionary).value(forKey: "church_name") as? String
        }
        
        return cell
    }
    
    // method to run when table view cell is tapped
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let objVC: AddappointmentViewController = storyboard?.instantiateViewController(withIdentifier: "AddappointmentViewController") as! AddappointmentViewController
self.navigationController?.pushViewController(objVC, animated: true)
        print("You tapped cell number \(indexPath.row).")
    }
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    // The number of rows of data
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return maindata.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
   
        return (maindata.object(at: row) as! NSDictionary).value(forKey: "church_area") as? String
    }
    @IBAction func btnsearchclicked(_ sender: Any) {
        pickerview.isHidden=true
        selectedindex = pickeroutlet.selectedRow(inComponent: 0)
        tableviewoutlet.reloadData()
        lblselected.text = (maindata.object(at: selectedindex) as! NSDictionary).value(forKey: "church_area") as? String

        setlocation(location: CLLocationCoordinate2D(latitude:Double( ((maindata.object(at: selectedindex) as! NSDictionary).value(forKey: "lattitude") as? String)!)!,longitude: Double( ((maindata.object(at: selectedindex) as! NSDictionary).value(forKey: "longitude") as? String)!)!))

    }
    @IBAction func btnpickerclicked(_ sender: Any) {
        pickeroutlet.selectRow(0, inComponent: 0, animated: false)
        pickerview.isHidden=false
    }

}

